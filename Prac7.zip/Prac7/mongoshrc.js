const { MongoClient } = require('mongodb');
const { faker } = require('@faker-js/faker');

async function insertPatients(dbName, colName, patientCount) {
    const client = new MongoClient('mongodb://localhost:27017');
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(colName);

        const patients = [];
        for (let i = 0; i < patientCount; i++) {
            patients.push({
                name: faker.person.fullName(),
                age: faker.number.int({ min: 1, max: 100 }),
                ailment: faker.helpers.arrayElement(['Cold', 'Flu', 'COVID-19', 'Allergy']),
                doctor: faker.person.fullName(),
                admitted: faker.datatype.boolean(),
                appointments: [
                    { date: faker.date.future(), reason: 'Initial checkup' },
                    { date: faker.date.future(), reason: 'Follow-up' }
                ]
            });
        }

        await collection.insertMany(patients);
        console.log(`${patientCount} patients inserted.`);
    } finally {
        await client.close();
    }
}

async function findAdmittedPatients(dbName, colName) {
    const client = new MongoClient('mongodb://localhost:27017');
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(colName);

        const admittedPatients = await collection.find({ admitted: true }).toArray();
        console.log(JSON.stringify(admittedPatients, null, 2));
        return admittedPatients;
    } finally {
        await client.close();
    }
}

async function updatePatientAdmission(dbName, colName, patientName, status) {
    const client = new MongoClient('mongodb://localhost:27017');
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(colName);

        await collection.updateOne({ name: patientName }, { $set: { admitted: status } });
        console.log(`Patient ${patientName} admission status updated to ${status}.`);
    } finally {
        await client.close();
    }
}

async function removeDischargedPatients(dbName, colName) {
    const client = new MongoClient('mongodb://localhost:27017');
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(colName);

        const result = await collection.deleteMany({ admitted: false });
        console.log(`${result.deletedCount} discharged patients removed.`);
    } finally {
        await client.close();
    }
}

async function findPatientsByAilment(dbName, colName, ailment) {
    const client = new MongoClient('mongodb://localhost:27017');
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(colName);

        const patientsWithAilment = await collection.find({ ailment: ailment }).toArray();
        console.log(JSON.stringify(patientsWithAilment, null, 2));
        return patientsWithAilment;
    } finally {
        await client.close();
    }
}

async function doctorStats(dbName, colName) {
    const client = new MongoClient('mongodb://localhost:27017');
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(colName);

        const pipeline = [
            { $group: { _id: "$doctor", patientCount: { $sum: 1 } } },
            { $sort: { _id: 1 } }
        ];

        const result = await collection.aggregate(pipeline).toArray();
        console.log(JSON.stringify(result, null, 2));
        return result;
    } finally {
        await client.close();
    }
}

async function doctorPatientList(dbName, colName, doctorName) {
    const client = new MongoClient('mongodb://localhost:27017');
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(colName);

        const patients = await collection.find({ doctor: doctorName }).toArray();
        console.log(JSON.stringify(patients, null, 2));
        return patients;
    } finally {
        await client.close();
    }
}

async function activeDoctorsMR(dbName, colName) {
    const client = new MongoClient('mongodb://localhost:27017');
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(colName);

        const pipeline = [
            { $group: { _id: "$doctor", patientCount: { $sum: 1 } } },
            { $out: "DoctorActivity" }
        ];

        await collection.aggregate(pipeline).toArray();
        console.log("DoctorActivity collection created.");
    } finally {
        await client.close();
    }
}

async function appointmentStats(dbName, colName) {
    const client = new MongoClient('mongodb://localhost:27017');
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(colName);

        const pipeline = [
            { $unwind: "$appointments" },
            {
                $project: {
                    doctor: "$doctor",
                    patient: "$name",
                    date: "$appointments.date",
                    reason: "$appointments.reason"
                }
            },
            {
                $group: {
                    _id: "$doctor",
                    appointments: {
                        $push: {
                            patient: "$patient",
                            date: "$date",
                            reason: "$reason"
                        }
                    }
                }
            },
            { $out: "Appointments" }
        ];

        await collection.aggregate(pipeline).toArray();
        console.log("Appointments collection created.");
    } finally {
        await client.close();
    }
}

async function dropAllCollections(dbName) {
    const client = new MongoClient('mongodb://localhost:27017');
    try {
        await client.connect();
        const db = client.db(dbName);

        const collections = await db.collections();
        for (let collection of collections) {
            await collection.drop();
            console.log(`Dropped collection: ${collection.collectionName}`);
        }
        console.log(`All collections in database ${dbName} have been dropped.`);
    } finally {
        await client.close();
    }
}

async function showCollectionContents(dbName, colName) {
    const client = new MongoClient('mongodb://localhost:27017');
    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(colName);

        const documents = await collection.find().toArray();
        console.log(`Contents of ${colName} collection:`);
        console.log(JSON.stringify(documents, null, 2));
    } finally {
        await client.close();
    }
}

// Example usage
(async () => {
    // await dropAllCollections('HospitalDB');
    // await insertPatients('HospitalDB', 'Patients', 10);
    // await findAdmittedPatients('HospitalDB', 'Patients');
    // await updatePatientAdmission('HospitalDB', 'Patients', 'Dora Hermann', true);
    // await removeDischargedPatients('HospitalDB', 'Patients');
    // await findPatientsByAilment('HospitalDB', 'Patients', 'Cold');
    // await doctorStats('HospitalDB', 'Patients');
    // await doctorPatientList('HospitalDB', 'Patients', 'Mr. Jason Windler');
    // await activeDoctorsMR('HospitalDB', 'Patients');
    // await appointmentStats('HospitalDB', 'Patients');
    // await showCollectionContents('HospitalDB', 'DoctorActivity');
    // await showCollectionContents('HospitalDB', 'Appointments');
})();