Terminal command:
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb/brew/mongodb-community
brew services list

(open shell):
mongosh

(create database):
use HospitalDB
db.createCollection("Patients")

(create mongoshrc.js file in your home directory)

(in ur file directory):
npm install mongodb faker

HOW TO RUN:
in one terminal:
# Navigate to your home directory
cd ~
# Install the required npm packages
npm install mongodb faker
# Run the JavaScript file
node mongoshrc.js

in another terminal:
#Start server
brew services start mongodb/brew/mongodb-community
# Open MongoDB shell
mongosh
# Switch to the HospitalDB database
use HospitalDB
# Verify inserted patients
db.Patients.find().pretty()

HOW TO STOP THE SERVER:
close MongoDB Shell:
exit

Stop MongoDB Service:
brew services stop mongodb/brew/mongodb-community